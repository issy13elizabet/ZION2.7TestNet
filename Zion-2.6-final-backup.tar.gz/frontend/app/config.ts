export const ZION_HOST = process.env.NEXT_PUBLIC_ZION_HOST || process.env.ZION_HOST || '91.98.122.165';
export const ZION_POOL_PORT = Number(process.env.NEXT_PUBLIC_ZION_POOL_PORT || process.env.ZION_POOL_PORT || 3333);
export const ZION_SHIM_PORT = Number(process.env.NEXT_PUBLIC_ZION_SHIM_PORT || process.env.ZION_SHIM_PORT || 18089);
