"use client";
import CosmicExplorer from '../components/CosmicExplorer';

export default function ExplorerPage() {
  return <CosmicExplorer />;
}
