"use client";
import CosmicMiningDashboard from '../components/CosmicMiningDashboard';

export default function MinerPage() {
  return <CosmicMiningDashboard />;
}
